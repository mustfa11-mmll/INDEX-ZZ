import 'package:flutter/material.dart';

class SearchScreenNew extends StatelessWidget {
  const SearchScreenNew({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: TextFormField(),
    );
  }
}
