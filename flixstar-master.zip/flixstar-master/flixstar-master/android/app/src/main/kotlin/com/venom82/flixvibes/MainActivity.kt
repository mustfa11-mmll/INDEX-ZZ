package com.venom82.flixvibes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
