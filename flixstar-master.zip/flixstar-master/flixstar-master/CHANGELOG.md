# Changelog

## [Unreleased]
- Control over Images Quality to Save Data uses by FlixStar
- An Option to make a Default Tab when launching the app

## [v1.0.0] - 02-07-2024
### First Release Features
    - Movies
    - Web Series(TV)
    - Anime

### [v1.0.2+9] - 18-08-2024
    - Fixed Firebase Permission Error That Causes Crash on App Launch

## [v1.0.2+10] - 18-08-2024
    - Fixed API Base URL

